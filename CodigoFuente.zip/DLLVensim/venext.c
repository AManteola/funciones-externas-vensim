/****************************************************************************
   extern.c -  Version 5.8c
   Copyright (c) 1992-2005 Ventana Systems, Inc.
   Example external function file definitions for use
   with Vensim

  Background:

  At their simplest external functions are simply mathematical routines
  that do things it is hard to do in Vensim.  In practice, however, most
  of the value of external functions comes from the ability to do
  programming language things.  In particular loops, iterations and
  conditional computation.  Thus there are a number of different
  attributes an external function can have.

  1. Use only floating point numbers as inputs and output a floating point
     number.

  2. Use a combination of floating point numbers and vectors (or arrays)
     of values to output a floating point number.  External functions can
     also take string variables and Lookups as arguments.

  3. Take over control of for variable loops from Vensim.

  4. Directly modify arguments passed as vectors.

  Of these number 1 is straightforward and is illustrated by the COSINE
  and INRANGE functions included here.  2 is straghtforward if you follow
  the example of the PSUM and MYMESSAGE function included here.  3 is tricky
  because the example of the Vensim function has 1 less argument than the
  real function, but should not cause problem if you follow example of the
  MATRIX_INVERT function included here.

  A special note on number 2 is that you can also use this function to
  create a simultaneous equation solver using your own solution algorithm.
  MYFINDZERO is an example of this.

  Number 4 is dangerous.  Vensim loses control of equation ordering and
  you can get unexpected results.  Use this only if you have to.  The
  MATRIX_INPLACE_INVERT function does this.  Be careful to study the model
  (venext.mdl) shipped with these examples.

  The rest of this file is broken up into 7 sections.  If you have more than
  a few functions, you should probably take section 2 and put it into a .h
  file.  Section 7 can be put in a separate file (or files) and the .h file
  included in thse files.  You most likely do not need to include <windows.h>
  in the other files (but <math.h> is a good idea.


  COMPILER NOTES

  Most of the development and testing of Vensim occurs using Microsoft
  compilers.  Visual C/C++

  If you want to write external functions in C plus plus you can rename this
  file to venext.cpp and everything should work OK.

  Note that you must include venext.def to get this all to work in your
  project (under Windows).

  CONFIGURATION NOTES

  Vensim's external functions can be used with Vensim DSS, Vensim Runtime,
  Vensim Application Runtime and the DLLs with the exception of the minimal
  DLL. In order to have external functions loaded in Application Runtime or
  the DLLs you will need to execute the command

      SPECIAL>READINI|inifile.ini

  where inifile.ini contains the line

      ExternalFunctionLibrary=c:\program files\vensim\comp\venext.dll

  set the path appropriate for where you have located you function library.
  There is no need to call the file venext.dll - any name will do.

  When you create your external function library you need to link with the
  .lib file associated with the program that will call your external functions.
  For Vensim DSS this is vensim.lib. For the Vensim DLL it is vendll32.lib
  and so on. If you do not do this loading the external functions will likely
  fail, possibly with a message that the application is not properly installed.


  PLATFORM NOTES

  Linux

  Standard C files such as this should work fine under Linux using shared
  object libraries. The sample make file venextun.mak can be used to build
  the shared object libary - alternatively just use the command

  gcc -shared venext.c -olibvenext.so

  because of the way Linux does runtime linking there is no need to reference
  the vensim symbols during compilation - references will be resolved at
  runtime.

  The format for indicating where to find the external function library
  is the same as on Windows - use the SPECIAL>READINI command. The path
  should follow Unix naming conventions eg

     ExternalFunctionLibrary=/home/bob/newven/comp/libvenext.so

  Remember that Linux is case sensitive so it is best to keep all filenames
  lower case.

  One thing worth noting about Linux is that the symbol space for shared object
  libraries is common and this means that it is possible to inadvertantly
  create functions or global variables which conflict with names in Vensim
  proper. Unfortunately, this tends to manifest itself only by causing
  catastrophic failure when the wrong function is called or the wrong
  global variable refrenced. For example, GLOB_VARS *VENGV used to be
  just GV which is used internally in Vensim and this causes a failure.
  If you suspect this type of problem try renaming the functions or
  variables to see if it helps.



   */

#define WANT_WINDOWS_INCLUDES /* the sample implementation of this requires windows includes/libraries */
#define VENEXT_GLOBALS
#include "./vensim.h"
#include <math.h>
#include <cblas.h>
#include <lapacke.h>
#include <string.h>

#ifdef unix
#include <stdlib.h>
#else
#include <malloc.h>
#endif

GLOB_VARS *VENGV='\0'; /* the value for this is set by set_gv below */

typedef struct SimpleMat {

    int dimension_number;
    int *dimensions;
    double *matrix_values;
    char *matrix_name;
} SimpleMat;


/*******************************************
 1 - function ids - used to switch between choices
 *******************************************/
#define INVERT_FUNC 0
#define SUM_FUNC 1
#define ADDMAT_FUNC 2
#define COMPUTE_TEST 3
#define GET_MAT 4
#define COMPUTE_INVERT 5

/*******************************************
 2 - function prototypes
 *******************************************
  each external function is prototyped here
  arguments can reasonably be doubles - for normal number manipulation,
  COMPREAL * for vector manipulation or int for indexing.  Recasting of
  values takes place in
  Note that if you use more than 1 file for the external function definitions
  you should probably put these prototypes into a #include file.  Also, for
  working with compiled simulation a # include file is helpfule, and should
  be nested into vensim.h

  Note that all the external functions are all upper case.  This is required
  if you want to use compile simulations - since the calls in mdl.c will
  be upper case.  Our apologies to those this offends.
*********************************************/
double MATRIXINVERT(VECTOR_ARG *invmat,VECTOR_ARG *mat1) ;
double MATRIXSUM(VECTOR_ARG *summat,VECTOR_ARG *result_mat,double ndims);
double INTERNALMATRIXINVERT(SimpleMat invmat,SimpleMat mat1) ;
double INTERNALMATRIXSUM(SimpleMat result_mat,SimpleMat sum_mat,double ndims);
void ADDMATRIX(VECTOR_ARG *given_mat, char* given_name);
double GETMATRIX(VECTOR_ARG *returnMat);
double COMPUTEINVERT(char *given_name);
SimpleMat getSimpleMat(VECTOR_ARG *given_mat, char *given_name);

/****************************************************
 3 - Grouping of functions in a structure - see venext.h
 ***********************************************************/

static FUNC_DESC Flist[] = {

                    {"MATRIXINVERT"," {matrix} ",1,1,INVERT_FUNC,2,0,0,0},
                    //{"ADDMATRIX"," {matrix}, {matrix name} ",2,1,ADDMAT_FUNC,0,0,0,0},
                    {"MATRIXSUM"," {matrix}, {#dimensions to collapse} ",2,1,SUM_FUNC,2,0,0,0},
                    //{"COMPUTEINVERT"," {matrix name} ",1,0,COMPUTE_INVERT,2,0,0,0},

                    {'\0',0,0,0}} ;

/******************************************************
 4 - DLL required functions LibMain and WEP
 Obsolete - 16 bit windows only
 ******************************************************/

/****************************************************************
 5 External function definitions
 ****************************************************************/

 /**************************
  This function is a version check - it is required to be sure
  the external functions are compatible with the current Vensim
  version. Note that for 5.8c this number has changed but you can
  simply update this version number, the set_gv function and the
  funcversion_info function (these 2 return different value types)
  make no other changes to your external functions and they will
  work. To simplify use with different configurations (ie the
  Model Reader and DLLs) we recommend that you not link with
  vensim.lib or vensimdp.lib and replace

  vensim_error_message with (*VENGV->error_message)
  vensim_alloc_simmem with (*VENGV->alloc_simmem)
  vensim_execute_curloop with (*VENGV->execute_curloop)

**********************/

int VEFCC version_info()
{
	return(EXTERNAL_VERSION) ;
}

/* When you make changes to functions update this. If Vensim opens a .vmf file
   that references aexternal functions and there is a mismatch a message will
   be given indicating that the model should be reformed and cleaned
   - if you return 0 no checking will occur

  If you have multiple external function libraries you can also use this to
  signal when a model is not matched to the library (though it won't indicate
  which library should be used) */
unsigned short VEFCC funcversion_info()
{
	return(1) ;
}

int VEFCC set_gv(GLOB_VARS *vgv)
{
	VENGV = vgv ;

	if (!VENGV
		|| VENGV->vgv_magic_start != VGV_MAGIC_START
		|| VENGV->vgv_magic_end != VGV_MAGIC_END)
	{
		return 0;
	}
	return 1 ;
}

  /* ****************************
   This function is _exported and called multiple times at Vensim
   startup with an index  - it returns 1 on success and 0 to
   indicate the end of the function list.  For convenience the structure
   defined in section 3 is used, but all the functions could also be declared
   with a switch statement on i
 *****************************************************************/

int VEFCC user_definition(
   int i, /* an index for requesting information - this is mapped to Flist
             but could be used another way - vensim repeatedly calls
             user_definition with i bigger by 1 until user_definition returns
             0 */
   unsigned char **sym,/* the name of the function to be used in the Vensim model */
   unsigned char **argument_desc, /* description of arguments to be used by the function */
   int *num_arg, /* the number of arguments (in Vensim) the function takes
                    note that for user loop functions this will be one less
                    than the number of arguments the function actually takes on */
   int *num_vector, /* the number of arguments that are passed as real number vectors */
   int *func_index, /* a number between 0 and 254 that identifies the function
                       vensim_external is called with this number */
   int *dim_act,  /* reserved - for doing dimensional analysis but not implemented */
   int *modify,  /* a flag to indicate that the function will modify value that
                    are passed to it -
                    0 is a normal function that does not modify its argument
                    1 is a function that does modify arguments
                    2 is a function that modifies arguments and serves as a solver
                      of a simultaneous set of conditions as FIND_ZERO */
  int *num_loop, /* the number of loops that are managed by the function -
                    this is nonzero (normally 1 or 2) for a function that
                    needs to return a vector or matrix of values - if this is
                    nonzero Vensim will put a pointer to the vector or array to
                    be filled in and pass it as the first argument to the function
                    NOTE use -1 for a constdef function and -2 for a datadef function */

  int *num_literal, /* the number of literals that are passed to the function -
                       arguments are always passed in the order literals,
                       lookups, vectors, numbers - if num_loop is set the
                       first argument is a vector even if num_literal is positive */
  int *num_lookup  /* the number of lookup functions passed - this structure is
                      not currently accessible but will be made so in the future */
  )
{
	if(Flist[i].sym)
	{
		*sym = (unsigned char *)Flist[i].sym ;
		*argument_desc = (unsigned char *)Flist[i].argument_desc ;
		*num_arg = Flist[i].num_args ;
		*num_vector = Flist[i].num_vector ;
		*func_index = Flist[i].func_index ;
		*dim_act = 0 ;
		*modify = Flist[i].modify ;
		*num_loop = Flist[i].num_loop ;
		*num_literal = Flist[i].num_literal ;
		*num_lookup = Flist[i].num_lookup ;
		return(1) ;
	}
	return(0) ; /* indicating the end of the list */
}

/***************************
 5a some memory management utility routines used by the examples that
    may be of value for other functions - note different routines
    to use Windows GlobalAlloc etc or just calloc etc
  ***************************************/
typedef struct _rorstr RORSTR ;
struct _rorstr
{
	COMPREAL *times ;
	HANDLE times_hndl ;
	COMPREAL *vals ;
	HANDLE vals_hndl ;
	RORSTR *next ;
	int streamid ;
	int ntimes ;
	int maxtimes ;
} ;

/* any flags that individual function need set to perform properly on the next
   invocation must be reset by vext_clearmem */
static int Matrix_invert_maxn ;
static int Matrix_sum_maxn ;
static int Max_mat_stored ;
static int Num_mat_stored ;
static int Add_matrix_init ;
static RORSTR *Internal_ror_fror ;

static HANDLE *Mem_used = '\0' ;
static int Num_mem_used = 0 ;
static int Max_mem_used = 0 ;


static void *vext_allocate(unsigned nbytes,HANDLE *hndl)
{
	HANDLE lhndl ;
	if(Num_mem_used >= Max_mem_used)
	{
		Max_mem_used += 100 ;
		if(Mem_used)
		{
			Mem_used = (HANDLE *)realloc(Mem_used,Max_mem_used*sizeof(HANDLE)) ;
			memset(Mem_used+Max_mem_used-100,'\0',100*sizeof(HANDLE)) ;
		}
		else
		{
			Mem_used = (HANDLE *)calloc(Max_mem_used, sizeof(HANDLE));
		}
	}

	if (!Mem_used)
	{
		return('\0');
	}

	lhndl = (HANDLE)malloc(nbytes);

	if (!lhndl)
	{
		return('\0');
	}

	if (hndl)
	{
		*hndl = lhndl;
	}

	Mem_used[Num_mem_used++] = lhndl ;
	return(lhndl) ;
}


static void *vext_reallocate(unsigned nbytes,HANDLE *hndl)
{
	int i ;

	if (!*hndl)
	{
		return(vext_allocate(nbytes, hndl));
	}

	if(Mem_used)
	{
		/* find old - otherwise live with the memory leak */
		for (i = 0; i < Num_mem_used; i++)
		{
			if (Mem_used[i] == *hndl)
			{
				break;
			}
		}
	}

	*hndl = realloc(*hndl,nbytes) ;

	if(Mem_used)
	{
		if (i < Num_mem_used)
		{
			Mem_used[i] = *hndl;
		}
	}
	return(*hndl) ;
}


static void vext_clearmem()
{
	int i ;

	if(Mem_used)
	{
		for(i=0;i<Num_mem_used;i++)
		{
			if(Mem_used[i])
			{
				free(Mem_used[i]) ;
			}
		}
		free(Mem_used) ;
	}

	Mem_used = '\0' ;
	Num_mem_used = Max_mem_used = 0 ;

	Matrix_invert_maxn = 0 ;
	Matrix_sum_maxn = 0 ;
	Add_matrix_init = 0 ;
	Max_mat_stored = 10 ;
	Num_mat_stored = 0 ;
	Internal_ror_fror = '\0' ;
}

/*********************************************************************
 6 - startup and shutdown routines
 *********************************************************************
    these two functions (if they exist and are exported)
    are called before the simulation starts and
    after it ends - in a normal simulation the order is
       simulation_setup(1) ;
       simulation_setup(0) ;
       simulation_shutdown(0) ;
       simulation_shutdown(1) ;
    for an optimization it the middle two calls are repeated for
    every simulation - the setup routine should return 0 on failure
    the return value is only used when iniflag == 1.  If the function
    returns 0 simulation will not proceed.
 ******************************************************************/

CFUNCTION int VEFCC simulation_setup(int iniflag)
{
	Matrix_sum_maxn = 0 ;
	Add_matrix_init = 0 ;
	Max_mat_stored = 10 ;
	Num_mat_stored = 0 ;
	return(1) ;
}

CFUNCTION int VEFCC simulation_shutdown(int finalflag)
{
	vext_clearmem() ;
	return(1) ;
}

/* this is a safety function to validate vector ranges when passing
   vectors to Vensim - you don't need to use it but it will help to
   prevent nasty memory errors */
static void validate_vector_arg(VECTOR_ARG *v,int nFirstIndex,int nLastIndex)
{
	int i ;

	if(nFirstIndex > nLastIndex)
	{
		i = nFirstIndex;
		nFirstIndex = nLastIndex;
		nLastIndex = i ;
	}

	if(v->vals + nFirstIndex < v->firstval
		|| v->vals+ nLastIndex > v->firstval + v->dim_info->u1.tot_vol)
	{
		(*VENGV->error_message)(VERROR,(unsigned char *)"Vector argument out of bounds") ;
		v->vals[0] = (COMPREAL)0.0 ;
		v->vals[0] = (COMPREAL)(1.0/v->vals[0]) ; /* generate a floating point exception */
	}
}


/*********************************************************************
 6 - vensim_external - the actual external function call
 *********************************************************************
   note that all the functions doing floating point are passed and
   return doubles to prevent any compiler specific problems from
   arising
 ******************************************************************/

CFUNCTION int VEFCC vensim_external(VV *val,int nval,int funcid)
{
	double rval ;

	switch(funcid)
	{

	case INVERT_FUNC :
		/* note that this function is self looping and therefore
		Vensim has added in another argument to this function.
		and this argument is passed by address.  Vensim passes all arrays
		as vectors - the last subscripts varies the fastest - in some cases
		you may also need to pass the size of the containing array if you
		are not operating on all elements. */
		rval = MATRIXINVERT(val[0].vec,val[1].vec) ;
		break ;

    case SUM_FUNC :
        rval = MATRIXSUM(val[0].vec,val[1].vec,val[2].val);
        break;

    case ADDMAT_FUNC :
        ADDMATRIX(val[0].vec, val[1].literal);
        rval = 0;
        break;

    case COMPUTE_INVERT :


	default :
		return(0) ; /* indicate an error condition to Vensim */
	}

	/* set val[0], this value will be used in the equation output */
	val[0].val = (COMPREAL)rval ;
	return(1) ; /* a 1 return value signals vensim of successful completetion */
}


/*************************************************************************
 7 - actual function bodies - these could be a separate file
 *************************************************************************
 actual function bodies are all set up to use and return doubles
 (except when acting on vectors) this aids portability across different
 platforms and compilers as the C standard for floating point argument
 passing uses doubles.
 *************************************************************************/


#define TINY_VAL ((COMPREAL)1.0E-20)



SimpleMat MATRIXSTORAGE(SimpleMat given_mat, int opCode, char *search_name){

    static HANDLE str_hndl;
    static SimpleMat **stored_mats;
    char *given_name;
    int given_dim_num, i, j, found;
    SimpleMat rtrn;
    switch(opCode)
    {
    case 1:
        //Shouldn't work on matrix made from getQuickSimpleMat. Use getSimpleMat to store matrix.

        given_name = given_mat.matrix_name;


        if(Add_matrix_init==1)
        {
            found = 0;
            for(j = 0; j < Num_mat_stored; j++){
                if(strcmp(stored_mats[j]->matrix_name, given_name) == 0){
                    found = 1;
                    break;
                }
            }



            if(found == 0){
                if(Num_mat_stored == Max_mat_stored)  //increase allocated memory for arrays of pointers if needed
                {
                    Max_mat_stored*=2;
                    stored_mats = (SimpleMat **)vext_reallocate(Max_mat_stored * sizeof(SimpleMat *), str_hndl);
                }

                stored_mats[Num_mat_stored] = &given_mat;



                Num_mat_stored++;
            } else {
                freeSimpleMat(stored_mats[j]);

                stored_mats[j] = &given_mat;


            }




        }
        else
        {





            stored_mats = (SimpleMat **)vext_allocate(Max_mat_stored * sizeof(SimpleMat *), str_hndl);


            stored_mats[Num_mat_stored] = &given_mat;

            Num_mat_stored++;

            Add_matrix_init = 1;
        }

        return given_mat;

    case 2:
        for(i = 0; i < Num_mat_stored; i++){
            if(strcmp(stored_mats[i]->matrix_name, search_name) == 0){
                rtrn = *(stored_mats[i]);
                return rtrn;
            }
        }
        return given_mat;


    default:

        return given_mat;

    }

}


SimpleMat getSimpleMat(VECTOR_ARG *given_mat, char *given_name){
    int given_dim_num, i, j, found;
    double mat_size;
    int *given_dims;
    double *given_values;
    double *vals;
    char *savedName;
    SimpleMat rtrn;


    given_dim_num = given_mat->dim_info->tot_dim;

    given_dims = (int *)vext_allocate(given_dim_num * sizeof(int), NULL);

    mat_size = 1;
    for(i = 0; i < given_dim_num; i++)  //get size of dimensions and total elements of matrix
    {
        given_dims[i] = given_mat->dim_info->u2.d.dim[i];
        mat_size = mat_size * given_dims[i];
    }


    given_values = (double *)vext_allocate(mat_size * sizeof(double), NULL);
    vals = given_mat->vals;
    for(j = 0; j < given_mat->dim_info->u1.tot_vol; j++){
        given_values[j] = vals[j];
    }
    savedName = (char *)vext_allocate(100 * sizeof(char), NULL);
    for(j=0; j<100; j++){
        if((savedName[j] = given_name[j]) == '\0') break;
    }




    rtrn.matrix_values = given_values;
    rtrn.dimensions = given_dims;
    rtrn.dimension_number = given_dim_num;
    rtrn.matrix_name=savedName;


    return rtrn;

}


SimpleMat getQuickSimpleMat(VECTOR_ARG *given_mat, char *given_name){
    //QuickSimpleMat doesn't reserve extra memory to copy the matrix values. It copies the value of the pointer, so changes made to a
    //QuickSimpleMat changes the original VECTOR_ARG it was made from.
    int given_dim_num, i, j, found;
    double mat_size;
    int *given_dims;
    double *given_values;
    double *vals;
    char *savedName;
    SimpleMat rtrn;


    given_dim_num = given_mat->dim_info->tot_dim;

    given_dims = (int *)vext_allocate(given_dim_num * sizeof(int), NULL);

    mat_size = 1;
    for(i = 0; i < given_dim_num; i++)  //get size of dimensions and total elements of matrix
    {
        given_dims[i] = given_mat->dim_info->u2.d.dim[i];
        mat_size = mat_size * given_dims[i];
    }



    given_values = given_mat->vals;
    savedName = (char *)vext_allocate(100 * sizeof(char), NULL);
    for(j=0; j<100; j++){
        if((savedName[j] = given_name[j]) == '\0') break;
    }




    rtrn.matrix_values = given_values;
    rtrn.dimensions = given_dims;
    rtrn.dimension_number = given_dim_num;
    rtrn.matrix_name=savedName;


    return rtrn;

}

void freeSimpleMat(SimpleMat mat){
    //Never call freeSimpleMat with a SimpleMat made from getQuickSimpleMat, this will crash Vensim.
    free(mat.dimensions);
    free(mat.matrix_name);
    free(mat.matrix_values);
}

void ADDMATRIX(VECTOR_ARG *given_mat, char* given_name){
    SimpleMat simple_given_mat;
    simple_given_mat = getSimpleMat(given_mat, given_name);
    MATRIXSTORAGE(simple_given_mat, 1, given_name);

    return;
}


double MATRIXINVERT(VECTOR_ARG *v_invmat,VECTOR_ARG *v_mat1)
{
    int i, n;
    SimpleMat parameter1, parameter2;
    double *vals;
    i = 0 ;
    	/* validate the last two dimensions are same on both and also the same
	if not issue an error message and cause a floating point exception to
	give more info about the error */


	if (v_invmat->dim_info->tot_dim < 2 || v_mat1->dim_info->tot_dim < 2)
	{
		i = 1;
	}
	else
	{
		n = (int)v_invmat->dim_info->u2.d.dim[v_invmat->dim_info->tot_dim-1] ;

		if (n != (int)v_invmat->dim_info->u2.d.dim[v_invmat->dim_info->tot_dim - 2]
			|| n != (int)v_mat1->dim_info->u2.d.dim[v_mat1->dim_info->tot_dim - 1]
			|| n != (int)v_mat1->dim_info->u2.d.dim[v_mat1->dim_info->tot_dim - 2])
		{
			i = 1;
		}
	}


	if(i)
	{
		(*VENGV->error_message)(VERROR, (unsigned char*) "Matrix inversion can only be preformed on square arrays (in last two dimensions)") ;
		v_invmat->vals[0] = (COMPREAL)0.0 ;
		return(1.0/v_invmat->vals[0]) ;/* cause a floating point exception */
	}
	parameter2 = getQuickSimpleMat(v_mat1, "v_mat1");
	parameter1 = getQuickSimpleMat(v_invmat, "v_invmat");
	INTERNALMATRIXINVERT(parameter1, parameter2);
	return v_invmat->vals[0];
}


double COMPUTEINVERT(char *given_name){
    SimpleMat invertedMatrix;
    invertedMatrix = MATRIXSTORAGE(invertedMatrix, 2, given_name);
    MATRIXSTORAGE(invertedMatrix, 1, given_name);
    return 1;

}

double INTERNALMATRIXINVERT(SimpleMat v_invmat,SimpleMat v_mat1)
{
	static HANDLE tmp_hndl, wrk_hndl, aux_hndl ;
	char errMessage[500];
	int i,j,k ;
	COMPREAL d ;
	double rval ;
	static lapack_int lwork;
	static double *work;
	double work_query;
	COMPREAL *scratch ;
	static double *tempmat ;
	int *indx;
	static int *vecAux;
	COMPREAL *col ;
	int n ;
	double *invmat, *mat1 ;
	lapack_int ret;



	invmat = v_invmat.matrix_values ;
	mat1 = v_mat1.matrix_values ;
	n = v_invmat.dimensions[v_invmat.dimension_number-1];


	/* If the size of the matrix is bigger than any received before, reserve the extra space needed.
	If it is the first execution, reserve the space for the matrix.*/

	if(n > Matrix_invert_maxn)
	{
		if (!Matrix_invert_maxn)
		{
			tempmat = (COMPREAL *)vext_allocate(n*n * sizeof(COMPREAL), &tmp_hndl);
			vecAux = (int *)vext_allocate((n+1)* sizeof(int), &aux_hndl);
			lwork = -1;
			//Calling the function with lwork value -1 returns in work_query the optimal size for lwork for a matrix of size n
            LAPACKE_dgetri_work(LAPACK_COL_MAJOR, n, tempmat, n, vecAux, &work_query, lwork);
            lwork = (lapack_int) work_query;
            work = (double*)vext_allocate(lwork*sizeof(double), &wrk_hndl);
		}
		else
		{
			tempmat = (COMPREAL *)vext_reallocate(n*n * sizeof(COMPREAL), &tmp_hndl);
			vecAux = (int *)vext_reallocate((n+1)* sizeof(int), &aux_hndl);
			lwork = -1;
            LAPACKE_dgetri_work(LAPACK_COL_MAJOR, n, tempmat, n, vecAux, &work_query, lwork);
            lwork = (lapack_int) work_query;
            work = (double*)vext_reallocate(lwork*sizeof(double), &wrk_hndl);
		}

		Matrix_invert_maxn = n ;
	}


	for(j=0, k=0;j<n;j++)
	{
		for (i = 0; i < n; i++, k++)
		{
			tempmat[k] = mat1[k];
		}
	}

    LAPACKE_dgetrf_work(LAPACK_COL_MAJOR,
        n,
        n,
        tempmat,
        n,
        vecAux);

    LAPACKE_dgetri_work(LAPACK_COL_MAJOR,
        n,
        tempmat,
        n,
        vecAux,
        work,
        lwork);



	for(j=0, k=0;j<n;j++)
	{
		for (i = 0; i < n; i++, k++)
		{
			invmat[k] = tempmat[k];
		}
	}






	rval = invmat[0] ; /* return first element */

	return(rval) ;
}


double MATRIXSUM(VECTOR_ARG *return_mat,VECTOR_ARG *v_summat, double ndims)
{
    SimpleMat parameter1, parameter2, parameter3;
    parameter1 = getQuickSimpleMat(v_summat, "v_summat");
    parameter2 = getQuickSimpleMat(return_mat, "return_mat");
    return INTERNALMATRIXSUM(parameter1, parameter2, ndims);
}



double INTERNALMATRIXSUM(SimpleMat s_return_mat,SimpleMat s_summat, double ndims)
{
    int i, j, k;
    double period = 1;
    double elements = 1;
    double sum;

    for(i = 1; i <= ndims; i++){
        period = period * s_summat.dimensions[s_summat.dimension_number-i];
    }
    for(i = 0; i < s_return_mat.dimension_number; i++){
        elements = elements * s_return_mat.dimensions[i];
    }
    k = 0;
    for(i = 0; i < elements; i++){
        sum = 0;
        for(j = 0; j < period; j++){
            sum = sum + s_summat.matrix_values[k];
            k++;
        }
        s_return_mat.matrix_values[i] = sum;
    }

	return 1;
}

